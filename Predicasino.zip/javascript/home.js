const correctPasscode = "PREDCAS00883";

function checkPasscode() {
    const enteredPasscode = document.getElementById('passcode').value;

    if (enteredPasscode === correctPasscode) {
        // Hide the popup if passcode is correct
        document.getElementById('passcode-popup').style.display = 'none';
    } else {
        // Alert if the passcode is incorrect
        alert("Incorrect passcode");
    }
}

// Auto-display the popup when the page loads
window.onload = function() {
    document.getElementById('passcode-popup').style.display = 'flex';
};