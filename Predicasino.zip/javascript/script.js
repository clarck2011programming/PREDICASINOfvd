document.addEventListener("DOMContentLoaded", function() {
    let progressBar = document.getElementById("progress-bar");
    let percentText = document.getElementById("percent");
    let statusText = document.getElementById("statusText");

    // Time in milliseconds (30 seconds)
    let duration = 30000;
    let interval = duration / 100;  // Update interval for progress bar (1% per 0.3 second)
    let progress = 0;

    // Footer status text changes every 3 seconds
    let statusMessages = [
        "Getting data...",
        "Please wait...",
        "Data retrieved successfully...",
        "Downloading resources...",
        "Resources downloaded successfully...",
        "Downloading images...",
        "Images downloaded successfully...",
        "Downloading pages...",
        "Pages downloaded successfully...",
        "Loading...",
        "Downloading GIF...",
        "GIF downloaded successfully...",
        "Please wait...",
        "Updating...",
        "Successfully!"
    ];

    let statusIndex = 0;
    function updateStatusText() {
        statusText.textContent = statusMessages[statusIndex];
        statusIndex = (statusIndex + 1) % statusMessages.length;
    }
    setInterval(updateStatusText, 2000); 

    // Update progress bar and percentage
    let progressInterval = setInterval(function() {
        if (progress <= 100) {
            progressBar.style.width = progress + "%";
            percentText.textContent = progress + "%";
            progress++;
        } else {
            clearInterval(progressInterval);  // Stop when progress reaches 100%
        }
    }, interval);
});


setTimeout(function() {
    window.location.href = "/Home";
}, 30000);